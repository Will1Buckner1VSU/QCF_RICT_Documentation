# Simulates coherence dipole effects
