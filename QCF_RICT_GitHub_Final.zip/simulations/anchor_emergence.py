# Simulates emergence of QCF anchors
